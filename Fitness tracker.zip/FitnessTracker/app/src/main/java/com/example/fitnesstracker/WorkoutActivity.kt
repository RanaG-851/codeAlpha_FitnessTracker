package com.example.fitnesstracker

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class WorkoutActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workout)

        db = FirebaseFirestore.getInstance()

        val recordWorkoutButton: Button = findViewById(R.id.record_workout_button)
        val exerciseText: EditText = findViewById(R.id.exercise_edittext)
        val durationText: EditText = findViewById(R.id.duration_edittext)
        val distanceText: EditText = findViewById(R.id.distance_edittext)
        val setsText: EditText = findViewById(R.id.sets_edittext)
        val repsText: EditText = findViewById(R.id.reps_edittext)
        val weightText: EditText = findViewById(R.id.weight_edittext)
        val dateText: EditText = findViewById(R.id.date_edittext)

        recordWorkoutButton.setOnClickListener {
            val exercise = exerciseText.text.toString()
            val duration = durationText.text.toString()
            val distance = distanceText.text.toString()
            val sets = setsText.text.toString()
            val reps = repsText.text.toString()
            val weight = weightText.text.toString()
            val date = dateText.text.toString()

            val workoutObject = Workout(exercise, duration, distance, sets, reps, weight, date)

            db.collection("users").document("userId").collection("workouts").add(workoutObject)
                .addOnSuccessListener { documentReference ->
                    Log.d("WorkoutActivity", "DocumentSnapshot added with ID: ${documentReference.id}")
                    Toast.makeText(baseContext, "Record Added.",
                        Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Log.w("WorkoutActivity", "Error adding document", e)
                    Toast.makeText(baseContext, "Error.",
                        Toast.LENGTH_SHORT).show()
                }
        }
    }
}