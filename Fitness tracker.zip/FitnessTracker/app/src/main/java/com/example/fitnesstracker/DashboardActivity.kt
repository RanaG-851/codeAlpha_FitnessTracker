package com.example.fitnesstracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore


class DashboardActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private var userId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        db = FirebaseFirestore.getInstance()
        userId = FirebaseAuth.getInstance().currentUser?.uid
        val workoutButton: Button = findViewById(R.id.workout_button)
        val goalButton: Button = findViewById(R.id.goal_button)
        val viewRecordButton: Button = findViewById(R.id.record_button)



        workoutButton.setOnClickListener {
            startActivity(Intent(this, WorkoutActivity::class.java))
        }

        goalButton.setOnClickListener {
            startActivity(Intent(this, GoalActivity::class.java))
        }

        viewRecordButton.setOnClickListener{
            startActivity(Intent(this,DisplayDataActivity::class.java))
        }

    }
}