package com.example.fitnesstracker

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class DisplayDataActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private val goals = mutableListOf<Goal>()
    private val workouts = mutableListOf<Workout>()
    private val goalAdapter = GoalAdapter(goals)
    private val workoutAdapter = WorkoutAdapter(workouts)
    private lateinit var goalsRecyclerView: RecyclerView
    private lateinit var workoutsRecyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_data)

        goalsRecyclerView = findViewById(R.id.goals_recyclerview)
        workoutsRecyclerView = findViewById(R.id.workouts_recyclerview)

        goalsRecyclerView.layoutManager = LinearLayoutManager(this)
        goalsRecyclerView.adapter = goalAdapter

        workoutsRecyclerView.layoutManager = LinearLayoutManager(this)
        workoutsRecyclerView.adapter = workoutAdapter

        fetchGoals()
        fetchWorkouts()
    }

    private fun fetchGoals() {
        db.collection("users").document("userId").collection("goals")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val goal = document.toObject(Goal::class.java)
                    goals.add(goal)
                }
                goalAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Log.w("DisplayDataActivity", "Error getting documents: ", exception)
            }
    }

    private fun fetchWorkouts() {
        db.collection("users").document("userId").collection("workouts")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val workout = document.toObject(Workout::class.java)
                    workouts.add(workout)
                }
                workoutAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Log.w("DisplayDataActivity", "Error getting documents: ", exception)
            }
    }
}
