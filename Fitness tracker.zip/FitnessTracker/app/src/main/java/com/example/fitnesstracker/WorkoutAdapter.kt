package com.example.fitnesstracker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WorkoutAdapter(private val workouts: List<Workout>) : RecyclerView.Adapter<WorkoutAdapter.WorkoutViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkoutViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_workout, parent, false)
        return WorkoutViewHolder(view)
    }

    override fun onBindViewHolder(holder: WorkoutViewHolder, position: Int) {
        holder.bind(workouts[position])
    }

    override fun getItemCount(): Int = workouts.size

    class WorkoutViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val exerciseTextView: TextView = itemView.findViewById(R.id.exercise_textview)
        private val durationTextView: TextView = itemView.findViewById(R.id.duration_textview)
        private val distanceTextView: TextView = itemView.findViewById(R.id.distance_textview)
        private val setsTextView: TextView = itemView.findViewById(R.id.sets_textview)
        private val repsTextView: TextView = itemView.findViewById(R.id.reps_textview)
        private val weightTextView: TextView = itemView.findViewById(R.id.weight_textview)
        private val dateTextView: TextView = itemView.findViewById(R.id.date_textview)
        fun bind(workout: Workout) {
            exerciseTextView.text = workout.exercise
            durationTextView.text = workout.duration
            distanceTextView.text = workout.distance
            setsTextView.text = workout.sets
            repsTextView.text = workout.reps
            weightTextView.text = workout.weight
            dateTextView.text = workout.date
        }
    }
}
