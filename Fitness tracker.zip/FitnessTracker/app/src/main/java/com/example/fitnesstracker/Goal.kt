package com.example.fitnesstracker

data class Goal(
    val goal: String = "",
    val deadline: String = ""
)
