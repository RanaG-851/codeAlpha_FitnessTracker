package com.example.fitnesstracker

data class Workout(
    val exercise: String = "",
    val duration: String = "",
    val distance: String = "",
    val sets: String = "",
    val reps: String = "",
    val weight: String = "",
    val date: String = ""
)
