package com.example.fitnesstracker

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class GoalActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal)

        db = FirebaseFirestore.getInstance()
        val setGoalButton: Button = findViewById(R.id.set_goal_button)
        val goalText: EditText = findViewById(R.id.goal_edittext)
        val deadlineText: EditText = findViewById(R.id.deadline_edittext)

        setGoalButton.setOnClickListener {
            val goal = goalText.text.toString()
            val deadline = deadlineText.text.toString()

            val goalObject = Goal(goal, deadline)

            db.collection("users").document("userId").collection("goals").add(goalObject)
                .addOnSuccessListener { documentReference ->
                    Log.d("GoalActivity", "DocumentSnapshot added with ID: ${documentReference.id}")
                    Toast.makeText(baseContext, "Goal Setted.",
                        Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Log.w("GoalActivity", "Error adding document", e)
                    Toast.makeText(baseContext, "Error.",
                        Toast.LENGTH_SHORT).show()
                }
        }
    }
}